var brand_config = {
	device : [{
			name : '<img class="device_1" src="./images/i_1.png" />'
		},{
			name : '<img class="device_2" src="./images/i_2.png" />'
		},{
			name : '<img class="device_3" src="./images/i_3.png" />'
	}]
}