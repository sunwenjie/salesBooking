function xmoCalendar(options){
	var _this = this;
	_this.daysInMonth = new Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
	_this.toDay = new Date();
	_this.tempYear = _this.toDay.getFullYear(); // 2013
	_this.tempMonth = _this.toDay.getMonth() + 1;   // 9 他的值是从0开始的。所以要加1才会得到真正的月份
  _this.today = _this.toDay.getDate();
  _this.day = _this.tempYear + '-' + _this.tempMonth + '-' + _this.today;
  _this.isShow = true;
  _this.boxId = new Date().getTime();
  _this.inputId = options['inputId'];
  _this.lang_opt = options['lang'] || 'EN';
  _this.inputObj = $(_this.inputId);
  _this.monthAry = [];
  _this.submitCallback = options['submitCallback'] || null;
  // 动态保存from 和 to的值
  _this.dateFrom = '';
  _this.dateTo = '';
  // from 和 to是否都已经选择
  _this.selectedDone = false;
  // 日历中所显示当前年月
  _this.currentFirstYear = 0;
  _this.currentFirstMonth = 0;

  _this.initTime = _this.dateToAry(options['initTime'] || _this.day);
  // 设定可用的时间范围
  _this.startTime = _this.dateToAry(options['startTime'] || '1980-12-11');
  _this.endTime = _this.dateToAry(options['endTime'] || '3000-12-11');
  // 被删除的时间
  _this.removed = {};
  _this.exclude_dates_obj = _this.inputObj.parent().find('.exclude_dates');
  _this.iconTrigger = options['iconTrigger'] || '.icon_trigger';
  // 初始化数据
  _this.init();
}
xmoCalendar.prototype.selecteOver = function(){
  var _this = this;
  _this.selectedDone = true;
  $('#' + _this.boxId).removeClass('inputingBox');
  $('#' + _this.boxId + ' input').blur();
  $('#' + _this.boxId + ' .xmoCalendarTableTips').html('');
}
xmoCalendar.prototype.selecting = function(){
  var _this = this;
  $('#' + _this.boxId + ' input').removeClass('inputing');
  $('#' + _this.boxId).addClass('inputingBox');
  _this.selectedDone = false;
  $('#' + _this.boxId + ' .xmoCalendarTableTips').html('');
}
xmoCalendar.prototype.init = function(){
  var _this = this;
  var lang = _this.lang[_this.lang_opt];
  // 初始化html结构
  var baseHtml = '<div class="xmoCalendarWraper" id="'+ _this.boxId +'"><svg class="svg-triangle" version="1.1" xmlns="http://www.w3.org/2000/svg"><polygon style="fill:#fff; stroke:#EEEEEE;stroke-width:1" points="0,9 6,0 12,9 "/><polygon style="fill:#fff; stroke:#fff;stroke-width:1" points="0,9 12,9 "/></svg><div class="xmoCalendarInner"><div class="xmoCalendarDataRange"><dl><dt>'+ lang['dateRange'] +'</dt></dl></div><div class="xmoCalendarMainArea"><div class="row xmoCalendarMainHead"><div class="span"><label class="sub_txt2">'+lang['from']+'<input type="text" class="xmoCalendarFrom" placeholder="YYYY-MM-DD"></label></div><div class="span r_margin_5"><label class="sub_txt2">'+lang['to']+'<input type="text" placeholder="YYYY-MM-DD" class="xmoCalendarTo"></label></div><div class="xmoCalendarError"></div></div><div class="cle"></div><div class="xmoCalendarTitle"><table><tr><td class="xmoCalendarMonth"></td><td class="xmoCalendarMonth"></td><td class="xmoCalendarMonth"></td></tr></table><div class="xmoCalendarPrev"></div><div class="xmoCalendarNext"></div></div><div class="xmoCalendarList"><div class="xmoCalendarTableWraper xmoCalendarTableWraperLast"></div><div class="cle"></div></div><div class="pull-left t_padding_10 xmoCalendarTableTips"></div><div class="outer_submit"><input value="'+ lang['submit'] +'" class="submit" type="button"></div><div class="xmoCalendarClear"></div></div><div class="cle"></div></div></div>';
  $('body').append(baseHtml);
  _this.xmoCalendarList = $('#' + _this.boxId).find('.xmoCalendarList');
  _this.btnLeft = $('#' + _this.boxId).find('.xmoCalendarPrev');
  _this.btnRight = $('#' + _this.boxId).find('.xmoCalendarNext');
  var xmoCalendarList = _this.getDataTable(_this.initTime[0],_this.initTime[1]);
  _this.xmoCalendarList.html(xmoCalendarList);
  _this.initDate();

  $(_this.inputId).focusin(function(){
     _this.showCalendar();
  });

  $(_this.inputId).parent().find(_this.iconTrigger).click(function(){
     _this.showCalendar();
  });
  _this.setMonth();
  _this.btnLeft.click(function(){
    _this.btnLeftFunc();
  });

  _this.btnRight.click(function(){
    _this.btnRightFunc();
  });

  $('#' + _this.boxId + ' .xmoCalendarMainHead input').focusin(function(){
    _this.selecting();
    $(this).addClass('inputing');
  }).change(function(){
    var date = $(this).val();
    if(date.length == 0) return false;
    var isExist = _this.checkDateExist(date);
    // 如果日期合法
    if(isExist){
      var val = _this.addZero(date);
      $(this).val(val);
      var dateCanBeUse = true;
      if($(this).hasClass('xmoCalendarFrom')){
        _this.dateFrom = val;
        dateCanBeUse = _this.checkDate(date,'from');
      }else{
        _this.dateTo = val;
        dateCanBeUse = _this.checkDate(date,'to');
      }
      var dateAry = _this.dateToAry(_this.dateFrom == '' ? _this.dateTo : _this.dateFrom);
      if(dateCanBeUse){
        $('#' + _this.boxId + ' input').removeClass('inputing');
      }
      _this.focusCheck();
      _this.currentFirstYear = dateAry[0];
      _this.currentFirstMonth = dateAry[1];
      _this.updateRemoved();
      _this.reTableList();
    }else{
      var lang = _this.lang[_this.lang_opt];
      _this.errorTip(lang['dateFormatUncorrect']);
    }
  });

  $(document).on('click','#' + _this.boxId + ' table td a:not(.disabled)',function(){
      var date = $(this).attr('title');
      var targetInput = $('#' + _this.boxId + ' .inputing');
      var dateFrom = $('#' + _this.boxId + ' .xmoCalendarFrom');
      var dateTo = $('#' + _this.boxId + ' .xmoCalendarTo');
      $('#' + _this.boxId + ' .xmoCalendarTableTips').html('');
      // 判断选择是否完成
      // 没有选择范围之前，焦点要么在from要么在to
      // 要检查数据的合法性
      // 1.选择已经完成
      var dateCanBeUse = true;
      if(targetInput.hasClass('xmoCalendarFrom')){
          dateCanBeUse = _this.checkDate(date,'from');
      }else if(targetInput.hasClass('xmoCalendarTo')){
          dateCanBeUse = _this.checkDate(date,'to');
      }
      if(!dateCanBeUse) return false;
      if(_this.selectedDone){
          // 判断是否在范围中 且已经选择
          // 删除一个日期
          if($(this).hasClass('selected')){
            var date_removed = $(this).attr('title');
            _this.tipsExcludeOneDayInEveryMonth(date_removed);
            _this.removed[date_removed] = true;
          }
          // 反删除一个日期
          if($(this).hasClass('removed')){
            var date_selected = $(this).attr('title');
            _this.tipsSelectOneDayInEveryMonth(date_selected);
            delete _this.removed[date_selected];
          }
      }else{
      // 1.选择没有完成
          targetInput.val(date).removeClass('inputing');
          if(targetInput.hasClass('xmoCalendarTo')){
            _this.dateTo = date;
          }else{
            _this.dateFrom = date;
          }
          _this.focusCheck();
      }
      targetInput.blur();
      _this.reTableList();
  })
  $(document).on('mouseover','#' + _this.boxId + ' table th a',function(){
      var index = $(this).attr('index');
      var selected = $(this).parents('table').first().find('a.selected[week="'+ index +'"]');
      var removed = $(this).parents('table').first().find('a.removed[week="'+ index +'"]');
      // 如果全部被删除了
      if(selected.length == 0 && removed.length > 0){
         $(this).attr('class','thSelectAllHover');
      }else if(selected.length > 0){
         $(this).attr('class','thRemoveAllHover');
      }
  })
  $(document).on('mouseout','#' + _this.boxId + ' table th a',function(){
         $(this).attr('class','');
  })

  $(document).on('click','#' + _this.boxId + ' table th a',function(){
      var index = $(this).attr('index');
      index = parseInt(index);
      var className = $(this).attr('class');

      if(className && className.indexOf('thRemoveAllHover') >= 0 && _this.selectedDone){
          _this.tipsAllWeekSelect(index,this);
      }else if(className && className.indexOf('thSelectAllHover') >= 0 && _this.selectedDone){
          _this.tipsAllWeekUnselect(index,this);
      }
  })

  $(document).on('click','#' + _this.boxId + ' .submit',function(){
      $('#' + _this.boxId).hide();
      var dateFrom = _this.dateFrom;
      var dateTo = _this.dateTo;
      var result = '';
      if(dateFrom.length > 0 && dateTo.length > 0)  result = dateFrom + ' ~ ' + dateTo;
      $(_this.inputId).val(result);
      _this.updateRemoved();
      _this.submitCallback && _this.submitCallback();
      $('#mask').remove();
  })
}

xmoCalendar.prototype.errorTip = function(msg){
  var _this = this,
      tipBox = _this.tipBox || (_this.tipBox = $('#' + _this.boxId + ' .xmoCalendarError'));
  tipBox.html(msg);
  clearInterval(_this.errorTipInterval);
  _this.errorTipInterval = setInterval(function(){
      tipBox.html('');
  },4000);
}

xmoCalendar.prototype.checkDateExist = function(date){
  var _this = this;
  var dateAry = _this.dateToAry(date);
  if(dateAry.length != 3) return false;
  var dateOneMonth = _this.getMonthData(dateAry[0],dateAry[1]);
  for (var i = 0; i < dateOneMonth.length; i++) {
    var item = dateOneMonth[i];
    for (var j = 0; j < item.length; j++) {
      var day = item[j] ;
       if(day['year'] == dateAry[0] && day['month'] == dateAry[1] && day['day'] == dateAry[2]) 
        {
          return true;
        }
    };
  };
  return false;
}

xmoCalendar.prototype.showCalendar = function(month, year){
  var _this = this;
  var $input = $(_this.inputId);
  var top = $input.offset().top + $input.outerHeight();
  var left = $input.offset().left;
  $('#' + _this.boxId).show().css({top : top,left:left,"z-index":100001});
  // $('#' + _this.boxId).show().css({top : top,left:left,"z-index":100000});
  var mask = $('<div id="mask"></div>').css({"z-index":100000,height:$(document).height(),width:$(document).width()}).click(function(){
    $('#' + _this.boxId).hide();
    $(this).remove();
  });
  $('body').append(mask);
  _this.initDate();
  _this.focusCheck();
}

xmoCalendar.prototype.initDate = function(){
  var _this = this;
  var inputDateOrigin = $(_this.inputId).val();
  inputDateOriginAry = inputDateOrigin.split('~');
  $('#' + _this.boxId + ' .xmoCalendarTableTips').html('');
  if(inputDateOriginAry.length == 2){
    _this.dateFrom = inputDateOriginAry[0];
    _this.dateTo = inputDateOriginAry[1];
    $('#' + _this.boxId + ' .xmoCalendarFrom').val(_this.dateFrom);
    $('#' + _this.boxId + ' .xmoCalendarTo').val(_this.dateTo);
    _this.selecteOver();
    var dateFromAry = _this.dateToAry(_this.dateFrom);
    _this.currentFirstYear = dateFromAry[0];
    _this.currentFirstMonth = dateFromAry[1];
    var romovedAry = _this.exclude_dates_obj.val().split(',');
    _this.removed = {};
    for(var i =0; i < romovedAry.length; i++){
      _this.removed[romovedAry[i]] = true;
    }
    _this.reTableList();
  }else{
    _this.dateFrom = '';
    _this.dateTo = '';
    // from 和 to是否都已经选择
    _this.selecting();
    _this.removed = {};
    $('#' + _this.boxId + ' .xmoCalendarFrom').val('');
    $('#' + _this.boxId + ' .xmoCalendarTo').val('');
    _this.reTableList();
  }
}

xmoCalendar.prototype.reTableList = function(){
  var _this = this;
  var xmoCalendarList = _this.getDataTable();
  _this.xmoCalendarList.html(xmoCalendarList);
  _this.setMonth();
}

// 周的选择
xmoCalendar.prototype.tipsAllWeekUnselect = function(index,element){
  var _this = this;
  var lang = _this.lang[_this.lang_opt];
  var tableEle = $(element).parents('table').first();
  var tableEleIndex = $('#' + _this.boxId + ' .xmoCalendarTableWraper table').index(tableEle);
  var headMsg = $('#' + _this.boxId + ' .xmoCalendarTitle tr td').eq(tableEleIndex).html();
  // 首先取消当前周的
  tableEle.find('tbody tr').each(function(){
    var target = $(this).find('td').eq(index);
    var target = target.find('a');
    if(target.length == 1){
      var date = target.attr('title');
      var isInrange = _this.isInRange(date);
      if(isInrange) delete _this.removed[date];
    }
  })
  _this.reTableList();
  // 然后取消询问是否取消其它周的
  var tipStr = '<strong>'+ lang['allWeekStrUnselect'][0] + ' ' + headMsg + ' ' + lang['aLongWeekStr'][index + 1] + lang['period']+ ' ' + '</strong><br/>'+ lang['allWeekStrUnselect'][1] + lang['aLongWeekStr'][index + 1] + lang['everyMonthStr'] +'?<span class="tipsAllWeekUnselect" index="'+ index +'">' + lang['yes'] + '</span>';
  var dateFrom = _this.dateFrom;
  var dateTo = _this.dateTo;
  var dateFromAry = _this.dateToAry(dateFrom);
  var dateToAry = _this.dateToAry(dateTo);

  var flag = true;
  var year = dateFromAry[0];
  var month = dateFromAry[1];
  var list = [];
  var len = 0;
  while(flag){
    if(year == dateToAry[0]&&month == dateToAry[1]) flag = false;
    if(month == 13){
      month = 01;
      year++;
    }

    var monthData = _this.getMonthData(year,month);
    for (var i = 0; i < monthData.length; i++) {
      var weekData = monthData[i];
      var item = weekData[index];
      if(item.day > 0){
        var thisDay = item.year+ '-' + _this.pad(item.month,2)+ '-' + _this.pad(item.day,2);
        var isInrange = _this.isInRange(thisDay);
        var isRemoved = _this.removed[thisDay];
        if(isInrange && isRemoved){
          list.push(thisDay);
        }
      }
    };
    month = _this.pad(++month,2);
  }
  $('#' + _this.boxId + ' .xmoCalendarTableTips').html('');
  if(list.length > 0){
    $('#' + _this.boxId + ' .xmoCalendarTableTips').html(tipStr);
    $('#' + _this.boxId + ' .tipsAllWeekUnselect').click(function(){
      for (var i = 0; i < list.length; i++) {
        var item = list[i];
        delete _this.removed[item]
      };
      $('#' + _this.boxId + ' .xmoCalendarTableTips').html('');
      _this.reTableList();
      return false;
    }).hover(function(){
      var index = $(this).attr('index');
      $('#' + _this.boxId + ' a.selected[week="'+ index +'"]').addClass('aHover');
      $('#' + _this.boxId + ' a.removed[week="'+ index +'"]').addClass('aHover');
    },function(){
      var index = $(this).attr('index');
      $('#' + _this.boxId + ' a.selected[week="'+ index +'"]').removeClass('aHover');
      $('#' + _this.boxId + ' a.removed[week="'+ index +'"]').removeClass('aHover');
    })
  }
}

// 周的取消
xmoCalendar.prototype.tipsAllWeekSelect = function(index,element){
  // 首先取消当前周的
  var _this = this;
  var lang = _this.lang[_this.lang_opt];
  var tableEle = $(element).parents('table').first();
  var tableEleIndex = $('#' + _this.boxId + ' .xmoCalendarTableWraper table').index(tableEle);
  var headMsg = $('#' + _this.boxId + ' .xmoCalendarTitle tr td').eq(tableEleIndex).html();
  tableEle.find('tbody tr').each(function(){
    var target = $(this).find('td').eq(index);
    var target = target.find('a');
    if(target.length == 1){
      var date = target.attr('title');
      var isInrange = _this.isInRange(date);
      if(isInrange) _this.removed[date] = true;
    }
  })
  _this.reTableList();
  // 然后取消询问是否取消其它周的
  var tipStr = '<strong>'+ lang['allWeekStr'][0] + ' ' + headMsg + ' ' + lang['aLongWeekStr'][index + 1] +lang['period'] +  ' ' + '</strong><br/>'+ lang['allWeekStr'][1] + lang['aLongWeekStr'][index + 1] + lang['everyMonthStr'] +'?<span class="tipsAllWeekSelect" index="'+ index +'">' + lang['yes'] + '</span>';
  var len = 0;
  var dateFrom = _this.dateFrom;
  var dateTo = _this.dateTo;
  var dateFromAry = _this.dateToAry(dateFrom);
  var dateToAry = _this.dateToAry(dateTo);

  var flag = true;
  var year = dateFromAry[0];
  var month = dateFromAry[1];
  var list = [];
  while(flag){
    if(year == dateToAry[0]&&month == dateToAry[1]) flag = false;
    if(month == 13){
      month = 01;
      year++;
    }

    var monthData = _this.getMonthData(year,month);
    for (var i = 0; i < monthData.length; i++) {
      var weekData = monthData[i];
      var item = weekData[index];
      if(item.day > 0){
        var thisDay = item.year+ '-' + _this.pad(item.month,2)+ '-' + _this.pad(item.day,2);
        var isInrange = _this.isInRange(thisDay);
        var isRemoved = _this.removed[thisDay];
        if(isInrange && !isRemoved){
          list.push(thisDay);
        }
      }
    };
    month = _this.pad(++month,2);
  }
  $('#' + _this.boxId + ' .xmoCalendarTableTips').html('')
  if(list.length > 1){
    $('#' + _this.boxId + ' .xmoCalendarTableTips').html(tipStr);
    $('#' + _this.boxId + ' .tipsAllWeekSelect').click(function(){
      for (var i = 0; i < list.length; i++) {
        var item = list[i];
        _this.removed[item] = true;
      };
    $('#' + _this.boxId + ' .xmoCalendarTableTips').html('')
      _this.reTableList();
      return false;
    }).hover(function(){
      var index = $(this).attr('index');
      $('#' + _this.boxId + ' a.selected[week="'+ index +'"]').addClass('aHover');
      $('#' + _this.boxId + ' a.removed[week="'+ index +'"]').addClass('aHover');
    },function(){
      var index = $(this).attr('index');
      $('#' + _this.boxId + ' a.selected[week="'+ index +'"]').removeClass('aHover');
      $('#' + _this.boxId + ' a.removed[week="'+ index +'"]').removeClass('aHover');
    })
  }
}

xmoCalendar.prototype.addZero = function(date){
  date = date.split('-');
  var _this =this;
  date[1] = _this.pad(date[1],2);
  date[2] = _this.pad(date[2],2);
  return date.join('-');
}

xmoCalendar.prototype.tipsSelectOneDayInEveryMonth = function(date){
  var _this = this;
  var lang = _this.lang[_this.lang_opt];
  // 如果在已经选择的日子中 存在多个这样的 没有被删除的日子 那么就显示提示
  var len = 0;
  var dateFrom = _this.dateFrom;
  var dateTo = _this.dateTo;
  var dateFromAry = _this.dateToAry(dateFrom);
  var dateToAry = _this.dateToAry(dateTo);
  var dateAry = _this.dateToAry(date);
  var tipStr = '<strong>'+ lang['allWeekStrUnselect'][0] + ' ' + date +lang['period'] +  '</strong><br/>'+ lang['allWeekStrUnselect'][1] + dateAry[2] + lang['allWeekStrUnselect'][2] + '<span class="tipsSelectOneDayInEveryMonth" day="'+ dateAry[2] +'">' + lang['yes'] + '</span>';
  var day = dateAry[2];
  var flag = true;
  var year = dateFromAry[0];
  var month = dateFromAry[1];
  var list = [];
  while(flag){
    if(year == dateToAry[0]&&month == dateToAry[1]) flag = false;
    if(month == 13){
      month = 01;
      year++;
    }
    var dateTest = [year,month,day].join('-');
    var isInrange = _this.isInRange(dateTest);
    var isRemoved = _this.removed[dateTest];
    var isExist = _this.checkDateExist(dateTest);
    if(isInrange && isRemoved && isExist){
      len++
      list.push(dateTest);
    }
    month = _this.pad(++month,2);
  }
  if(len > 1){
    $('#' + _this.boxId + ' .xmoCalendarTableTips').html(tipStr);
  }
  $('#' + _this.boxId + ' .tipsSelectOneDayInEveryMonth').click(function(){
    for (var i = 0; i < list.length; i++) {
      var item = list[i];
      item = _this.addZero(item);
      delete _this.removed[item];
    };
    $('#' + _this.boxId + ' .xmoCalendarTableTips').html('')
    _this.reTableList();
    return false;
  }).hover(function(){
    var day = $(this).attr('day');
    $('#' + _this.boxId + ' a.selected[day="'+ day +'"]').addClass('aHover');
    $('#' + _this.boxId + ' a.removed[day="'+ day +'"]').addClass('aHover');
  },function(){
    var day = $(this).attr('day');
    $('#' + _this.boxId + ' a.selected[day="'+ day +'"]').removeClass('aHover');
    $('#' + _this.boxId + ' a.removed[day="'+ day +'"]').removeClass('aHover');
  })
}

xmoCalendar.prototype.tipsExcludeOneDayInEveryMonth = function(date){
  var _this = this;
  var lang = _this.lang[_this.lang_opt];
  // 如果在已经选择的日子中 存在多个这样的 没有被删除的日子 那么就显示提示
  var len = 0;
  var dateFrom = _this.dateFrom;
  var dateTo = _this.dateTo;
  var dateFromAry = _this.dateToAry(dateFrom);
  var dateToAry = _this.dateToAry(dateTo);
  var dateAry = _this.dateToAry(date);
  var tipStr = '<strong>'+ lang['allWeekStr'][0] + ' ' + date + lang['period']  + '</strong><br/>'+ lang['allWeekStr'][1] + dateAry[2] + lang['allWeekStr'][2] + '<span class="tipsExcludeOneDayInEveryMonth" day="'+ _this.pad(dateAry[2],2) +'">' + lang['yes'] + '</span>';
  var day = dateAry[2];
  var flag = true;
  var year = dateFromAry[0];
  var month = dateFromAry[1];
  var list = [];
  while(flag){
    if(year == dateToAry[0]&&month == dateToAry[1]) flag = false;
    if(month == 13){
      month = 01;
      year++;
    }
    var dateTest = [year,month,day].join('-');
    var isInrange = _this.isInRange(dateTest);
    var isRemoved = _this.removed[dateTest];
    var isExist = _this.checkDateExist(dateTest);
    if(isInrange && !isRemoved && isExist){
      len++
      list.push(dateTest);
    }
    month = _this.pad(++month,2);
  }
  if(len > 1){
    $('#' + _this.boxId + ' .xmoCalendarTableTips').html(tipStr);
  }
  $('#' + _this.boxId + ' .tipsExcludeOneDayInEveryMonth').click(function(){
    for (var i = 0; i < list.length; i++) {
      var item = list[i];
      item = _this.addZero(item);
      _this.removed[item] = true;
    };
    $('#' + _this.boxId + ' .xmoCalendarTableTips').html('')
    _this.reTableList();
    return false;
  }).hover(function(){
    var day = $(this).attr('day');
    $('#' + _this.boxId + ' a.selected[day="'+ day +'"]').addClass('aHover');
    $('#' + _this.boxId + ' a.removed[day="'+ day +'"]').addClass('aHover');
  },function(){
    var day = $(this).attr('day');
    $('#' + _this.boxId + ' a.selected[day="'+ day +'"]').removeClass('aHover');
    $('#' + _this.boxId + ' a.removed[day="'+ day +'"]').removeClass('aHover');
  })
}
/*
  自动补零
  pad(100, 4);  // 输出：0100  
*/
xmoCalendar.prototype.pad = function(num, n) {
    var len = num.toString().length;  
    while(len < n) {
        num = "0" + num;
        len++;
    }
    return num;  
}
/*
*检查From 和 To日期
*
*
*/ 
xmoCalendar.prototype.checkDate = function(date,type) {
  var _this = this;
  var lang = _this.lang[_this.lang_opt];

  if(type == 'from'){
    if(_this.dateTo == '' || date == _this.dateTo) return true
    var isInrange = _this.isInRange(date,'1977-01-01',_this.dateTo);
    if(!isInrange){
      // _this.errorTip(lang['err_1']);
      _this.dateTo = '';
      _this.removed = {};
      $('#' + _this.boxId + ' .xmoCalendarTo').val('');
      return true;
    }
  }else if(type == 'to'){
    if(_this.dateFrom == '' ||  date == _this.dateFrom) return true
    var isInrange = _this.isInRange(date,'1977-01-01',_this.dateFrom);
    if(isInrange){
      _this.errorTip(lang['err_2']);
      return false;
    }
  }
  return true;
}

xmoCalendar.prototype.focusCheck = function(){
  var _this = this;
  var dateFrom = $('#' + _this.boxId + ' .xmoCalendarFrom');
  var dateTo = $('#' + _this.boxId + ' .xmoCalendarTo');
  if(dateFrom.val().length == 0){
    dateFrom[0].focus();
    return false;
  }
  if(dateTo.val().length == 0){
    dateTo[0].focus();
    return false;
  }
  // input to
  if(dateFrom.val().length > 0 && dateTo.val().length > 0){
    _this.selecteOver();
  }else{
    _this.selecting();
  }
}

xmoCalendar.prototype.dateToAry = function(date){
  var date = date.split('-');
  for(var i = 0; i < 3; i++){
    date[i] = this.pad(parseInt(date[i]),2);
  }
  return date;
}

xmoCalendar.prototype.isInRange = function(date,start,end){
  var _this = this;
  var dateFrom = start || _this.dateFrom;
  var dateTo = end || _this.dateTo;
  var dateAry = _this.dateToAry(date);
  var dateFromAry = _this.dateToAry(dateFrom);
  var dateToAry = _this.dateToAry(dateTo);
  var millisecondsFrom = (new Date(dateFromAry[0],dateFromAry[1]-1,dateFromAry[2])).getTime();
  var millisecondsTo = (new Date(dateToAry[0],dateToAry[1]-1,dateToAry[2])).getTime();
  var milliseconds = (new Date(dateAry[0],dateAry[1]-1,dateAry[2])).getTime();
  if(milliseconds <= millisecondsTo&&millisecondsFrom <= milliseconds) return true;
  return false;
}

xmoCalendar.prototype.btnLeftFunc = function(){
  var _this = this;
  var year =   _this.currentFirstYear;
  var month =  _this.currentFirstMonth;
  if(month -3 <= 0){
    month = month + 9;
    year -= 1;
  }else{
    month -= 3;
  }
  var xmoCalendarList = _this.getDataTable(year,month);
  _this.xmoCalendarList.html(xmoCalendarList);
  $('#' + _this.boxId).show();
  _this.setMonth();
}

xmoCalendar.prototype.btnRightFunc = function(){
  var _this = this;
  var year =   _this.currentFirstYear;
  var month =  parseInt(_this.currentFirstMonth);
  if(month + 3 > 12){
    month = month - 9;
    year += 1;
  }else{
    month += 3;
  }
  var xmoCalendarList = _this.getDataTable(year,month);
  _this.xmoCalendarList.html(xmoCalendarList);
  $('#' + _this.boxId).show();
  _this.setMonth();
}

/*
  改变月份显示 和 左右按钮的显示
*/ 
xmoCalendar.prototype.setMonth = function(){
  var _this = this;
  $('#' + _this.boxId + ' .xmoCalendarMonth').each(function(index,ele){
    $(ele).html(_this.monthAry[index]);
  })
}

/*
  把删除的日期值添加到隐藏的input中
*/ 
xmoCalendar.prototype.updateRemoved = function(){
    var _this = this;
    var removedAry = [];
    for(var i in _this.removed){
      var isInRange = _this.isInRange(i);
      if(i.length > 0 && isInRange){
        removedAry.push(i);
      }else{
        delete _this.removed[i];
      }
    }
    _this.exclude_dates_obj.val(removedAry.join(','));
}

xmoCalendar.prototype.getDataTable = function(year,month){
  var _this = this;
  var lang = _this.lang[_this.lang_opt];
  var year = year || _this.currentFirstYear;
  var month = month || _this.currentFirstMonth;
  var html = '';
  var tableHead = '<thead><tr><th><a href="javascript:void(0);" index="0">'+ lang['aWeekStr'][1] +'</a></th><th><a href="javascript:void(0);" index="1">'+ lang['aWeekStr'][2] +'</a></th><th><a href="javascript:void(0);" index="2">'+ lang['aWeekStr'][3] +'</a></th><th><a href="javascript:void(0);" index="3">'+ lang['aWeekStr'][4] +'</a></th><th><a href="javascript:void(0);" index="4">'+ lang['aWeekStr'][5] +'</a></th><th><a href="javascript:void(0);" index="5">'+ lang['aWeekStr'][6] +'</a></th><th><a href="javascript:void(0);" index="6">'+lang['aWeekStr'][7] +'</a></th></tr></thead>';
  for (var k = 0; k < 3; k++) {
    var tableData = _this.getMonthData(year,month);
    var table = '<div class="xmoCalendarTableWraper"><table class="xmoCalendarTable">'
    if(k == 2){
      table = '<div class="xmoCalendarTableWraper xmoCalendarTableWraperLast"><table class="xmoCalendarTable">';
    }
    if(k == 0){
      _this.currentFirstYear = year;
      _this.currentFirstMonth = month;
    }
    var tbody = '<tbody>';
    table += tableHead;
    if(_this.lang_opt == 'CN'){
       _this.monthAry[k] = year + '年  '+ _this.pad(month,2) + '月';
    }else{
       _this.monthAry[k] = lang['aLongMonStr'][month-1] + '&nbsp;' +  year
    }
    if(month == 12){
      month = 01;
      year++;
    }else{
      month = _this.pad(++month,2)
    }
      // 拼出每周的
    for (var i = 0; i < 6; i++) {
      var tr = '<tr>';
      var weekAry = tableData[i];
      if(weekAry == undefined){
        weekAry = [{day:0},{day:0},{day:0},{day:0},{day:0},{day:0},{day:0}]
      }
      for (var j = 0; j < weekAry.length; j++) {
        var item = weekAry[j];
        var aClass = '';
        if(item.day == 0){
          tr += '<td>&nbsp;</td>';
        }else{
          var thisDay = item.year+ '-' + _this.pad(item.month,2)+ '-' + _this.pad(item.day,2);
          if(_this.day == thisDay) aClass = 'today';
          if(_this.selectedDone){
            var isInRange = _this.isInRange(thisDay);
            if(isInRange){
              aClass = 'selected ';
            }
          }else{
            if(thisDay == _this.dateFrom || thisDay == _this.dateTo) aClass = 'selected'
            if(thisDay == $('#' + _this.boxId + ' .xmoCalendarFrom').val()) aClass = 'justSelected'
          }
          var canBeSelect = _this.isInRange(thisDay,_this.startTime.join('-'),_this.endTime.join('-'));
          if(!canBeSelect){
            aClass = 'disabled';
          }
          if(_this.removed[thisDay]) aClass = 'removed';
          tr += '<td><a href="javascript:void(0);" class="'+ aClass +'" week="'+ j +'"  day="'+ _this.pad(item.day,2) +'" title="'+ thisDay +'">'+ item.day +'</a></td>';
        }
      };
      tr += '</tr>';
      tbody += tr;
    };
    tbody += '</tbody>';
    table += tbody + '</table></div>';
    html += table;
  }
  html += '<div class="cle"></div>';
  // $('.xmoCalendarList').html(html + '<div class="cle"></div>');
  return html;
}

/*
月 +1之后的月份
*/ 
xmoCalendar.prototype.getMonthData = function(year,month){
    var _this = this;
    var data = [];
  	var tempYear = new Date(year, month-1, 1);
    var daily = 0;
  	var startDay = tempYear.getDay();// 从 Date 对象返回一周中的某一天 (0 ~ 6)。  周日为0
  	// 本月共有多少天
  	var intDaysInMonth = _this.getDaysInMonth( month-1,year);
	   // 共有几周
  	var weeks = (intDaysInMonth + startDay) % 7 == 0 ? (intDaysInMonth + startDay) / 7 : parseInt((intDaysInMonth + startDay) / 7) + 1;
  	for (var intWeek = 1; intWeek <= weeks; intWeek++) {
      var weekData = []
	    for (var intDay = 0; intDay < 7; intDay++) {
        var dayObj = {};
  			if ((intDay == startDay) && (0 == daily)) daily = 1;
          dayObj.year = year;
          dayObj.month = month;
        if ((daily > 0) && (daily <= intDaysInMonth)) {
          dayObj.day = daily;
  				daily++;
  			} else {
          dayObj.day = 0;
  			}
        weekData.push(dayObj)
		  }
      data.push(weekData);
	   }
     return data;
}

/*
	获取一个月有多少天
*/ 
xmoCalendar.prototype.getDaysInMonth = function(month, year){
	var _this = this;
  if (1 == month) return ((0 == year % 4) && (0 != (year % 100))) || (0 == year % 400) ? 29 : 28;
  else return _this.daysInMonth[month];
}

xmoCalendar.prototype.lang = {
  'CN' : {
      errAlertMsg: "选择时间超出范围，是否继续？",
      aWeekStr: ["周", "日", "一", "二", "三", "四", "五", "六"],
      aLongWeekStr:["周", "周日", "周一", "周二", "周三", "周四", "周五", "周六"],
      aMonStr: ["一","二","三","四","五","六","七","八","九","十","十一","十二"],
      aLongMonStr: ["一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一月","十二月"],
      clearStr: "清除",
      todayStr: "今天",
      okStr: "好",
      updateStr: "好",
      timeStr: "时间",
      quickStr: "快速选择",
      err_1: '开始日期不能大于结束日期',
      err_2: '结束日期不能小于开始日期',
      dateRange : '日期范围',
      from:'从',
      to:'到',
      submit : '提交',
      yes : '是',
      allWeekStr : ['您已经取消了','是否要取消选择其它月份的','号?'],
      allWeekStrUnselect : ['您已经选择了','是否要选择其它月份的','号?'],
      everyMonthStr : '',
      dateFormatUncorrect : '日期格式不正确',
      period : '。'
  },
  'EN' : {
      errAlertMsg: "Invalid date or the date out of range,redo or not?",
      aWeekStr: ["wk", "Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
      aLongWeekStr:["wk","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],
      aMonStr: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
      aLongMonStr: ["January","February","March","April","May","June","July","August","September","October","November","December"],
      clearStr: "Clear",
      todayStr: "Today",
      okStr: "OK",
      updateStr: "OK",
      timeStr: "Time",
      quickStr: "Quick Selection",
      err_1: 'Start date cannot be greater than end date',
      err_2: 'End date cannot be less than start date',
      dateRange : 'Date Range',
      from:'From',
      to:'To',
      submit : 'Submit',
      yes : 'Yes',
      allWeekStr : ['You have excluded','Would you like to exclude ','th in every month?'],
      allWeekStrUnselect : ['You have selected','Would you like to select ','th in every month?'],
      everyMonthStr : ' in every month',
      dateFormatUncorrect : 'Date format is not correct',
      period : '.'
  }
}
